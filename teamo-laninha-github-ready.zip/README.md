# 💖 Te Amo Laninha

Este site foi criado como uma homenagem romântica, com animações, contador do nosso tempo juntos e a música _This I Love_ do Guns N' Roses tocando via Spotify.

## 🌟 Recursos

- Animação estilo "Matrix" com declarações de amor
- Explosões interativas de "te amo" ao toque
- Contador de tempo desde o início do relacionamento
- Player oficial do Spotify incorporado com a música favorita

## 📱 Como visualizar

1. Acesse este repositório no GitHub
2. Vá para a aba **Settings > Pages**
3. Ative o GitHub Pages usando a branch `main` e a raiz `/`
4. Após alguns segundos, seu site estará disponível em:

```
https://<seu-usuario>.github.io/teamo-laninha
```

## 💌 Dedicado com amor

Feito para você, Laninha.  
Te amo hoje e sempre. 💘
